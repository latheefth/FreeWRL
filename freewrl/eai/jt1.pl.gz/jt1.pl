# Very simple: just get the TouchSensor event and give
# a random color to the other box.

# NOTE - this does not work very well, at all!!!! Have
# to figure out how best to fix it. JAS.


$PORT=90000;

use IO::Socket;

$server = IO::Socket::INET->new(Proto => 'tcp',
	LocalPort => $PORT,
	Listen => SOMAXCONN,
	Reuse => 1) or die("Can't set up server");
system("perl ./freewrl eai/t1.wrl -best -eai localhost:$PORT eai &");


$sock = $server->accept();
$sock->autoflush(1);

sub getlines {
	print "jt1.pl getlines starting\n";
	my @arr;
	for(1..$_[0]) {
		print "jt1.pl EXPECTING ROW $_\n";
		my $str = <$sock>;
		chomp $str;
		print "jt1.pl GOT '$str'\n";
		push @arr, $str;
	}
        print "jt1.pl returning from getlines @arr\n";
	return @arr;
}

# Test the sample EAI protocol.

$a = <$sock>;
$sock->print("TJL EAI CLIENT 0.02\n");

$sock->print("1\nGN TS\n");
my @l = getlines(4);
# print "\njt1.pl ok, REAL node of TS is $l[3]\n\n";


$sock->print("2\nGN MAT\n");
my @m = getlines(4);
# print "\njt1.pl ok, node of MAT  is $m[3]\n\n";


# print "jt1.pl SENDING 3 RL $l[3] TouchTime XX\n";
$sock->print("3\nRL $l[3] touchTime XX\n");

my @l2 = getlines(4);
# print "jt1.pl - Touchtime returned @l2\n";



# XXX This is fragile - it breaks if user clicks quickly and two events
# come before our response gets to them

while(@x = getlines(3)) {
	print "jt1.pl in while loop with @x\n";
	if($x[1] ne "XX") {die("Invalid ev '$x[1]'")}
	$sock->print("15\nSE $m[3] diffuseColor\n".(join ' ',map {rand} 0..2)."\n");
	#@y = getlines(4);
        #print "jt1.pl finishing while loop with @y\n";
}
