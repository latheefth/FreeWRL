$PORT=90001;

use IO::Socket;

$server = IO::Socket::INET->new(Proto => 'tcp',
	LocalPort => $PORT,
	Listen => SOMAXCONN,
	Reuse => 1) or die("Can't set up server");

system ("perl ./freewrl -eai localhost:90001 ./eai/EAISimple.wrl eai &");


$sock = $server->accept();
$sock->autoflush(1);

# print "jt6.pl EAI CLIENT STARITNG!!!!!\n";

sub getlines {
	# print "jt6.pl getlines starting\n";
	my @arr;
	for(1..$_[0]) {
		# print "jt6.pl EXPECTING ROW $_\n";
		my $str = <$sock>;
		chomp $str;
		# print "jt6.pl GOT '$str'\n";
		push @arr, $str;
	}
        print "jt6.pl returning from getlines @arr\n";
	return @arr;
}

# Test the sample EAI protocol.

$a = <$sock>;
$sock->print("TJL EAI CLIENT 0.02\n");

#---------------------


#---------------------

# make a cone for the avatar...
#$sock->print("4\nCVS Transform {translation -5.0 3.0 3.0 children [ Shape {geometry Cone{}}]}\nEOT\n");

#my @def = getlines(4);
#print "jt6.pl - CVS of cone returned @def\n\n\n\n\n\n\n";
##system ("sleep 2");

#---------------

# Step 1.Initial starting code.


# system ("sleep 5");

#EAI input:1GN ROOTNODE
#EAI input:3GN VIEWPOINT
#EAI input:7GN BIGBOX
#EAI input:8GN VNET
print "jt6.pl starting step 1\n";

$sock->print("1\nGN ROOTNODE\n");
my @root = getlines(4);
print "\njt6.pl REAL node of ROOTNODE is $root[3]\n\n";

$sock->print("3\nGN VIEWPOINT\n");
my @view = getlines(4);
print "\njt6.pl REAL node of VIEWPOINT is $view[3]\n\n";

$sock->print("7\nGN BIGBOX\n");
my @bb = getlines(4);
print "\njt6.pl REAL node of BIGBOX is $bb[3]\n\n";

$sock->print("8\nGN VNET\n");
my @vnet = getlines(4);
print "\njt6.pl REAL node of VNET is $vnet[3]\n\n";
#system ("sleep 2");


#--------------------------

# step 2. Register this listener, and turn lights on.
# note, we don't register, as this program has no way
# of handling EVents!!!!

#EAI input:16RL  BIGBOX  position_changed 16
#EAI input:17RL  BIGBOX  orientation_changed 17
#EAI input:21SE  VNET  isConnectedTRUE

print "jt6.pl starting step 2\n";
$sock->print("21\nSE $vnet[3] isConnected\nTRUE\n");


# --------------------------

# step 3. Send in the first proto for the first avatar.
# this is the avatar for the externally connected user.
# (only simulate one user, for now!) Register listener
# for the avatar, but don't do it here...

#EAI input:22CVS PROTO ....
#EAI input:34RL  AVATAR_1  clicked 34
#EAI input:35RL  AVATAR_1  objectNodes 35

print "jt6.pl starting step 3\n";
# The "full" avatar...
$sock->print("22\nCVS PROTO Avatar [ exposedField SFVec3f position 0 5 0 ",
    "exposedField SFRotation orientation 0 0 0 0 exposedField SFVec3f scale ",
    "1.0 1.0 1.0 exposedField MFString name \"\" exposedField MFNode ",
    "objectNodes [] exposedField MFNode textNodes [] eventOut SFBool clicked ",
    "] { Transform { translation IS position rotation IS orientation children [ ",
    "Collision { collide FALSE children [ ",
#    "Shape { appearance Appearance { material Material {}} geometry Box {} }",
#    "Transform {translation -1.0 0.0 1.0 children [ Shape {geometry Box{}}]}",
    "Transform { rotation 0 1 0 3.14159 children [ Transform { translation ",
    "0.0 0.7 0.0 scale 0.2 0.2 0.2 children Billboard { children IS textNodes ",
    "} } Transform { scale IS scale children IS objectNodes } TouchSensor { ",
    "isActive IS clicked } ] } ] } ] } } Avatar {} \nEOT\n");
#

my @proto1 = getlines(4);
print "jt6.pl - CVS of PROTO Avatar 1 returned @proto1\n";

# --------------------------


# step 4. Now, parse the first avatar, add it to the proto, and set the position.
#EAI input:36CVU TinMan.wrl
#EAI input:38SE  AVATAR_1  objectNodes TINMAN_WRL 
#EAI input:39SE  AVATAR_1  position0.0 0.0 10.0
#EAI input:40SE  VIEWPOINT  set_bindFALSE
#EAI input:41SE  VIEWPOINT  position0.0 0.0 10.0
#EAI input:42SE  VIEWPOINT  set_bindTRUE
#EAI input:43SE  AVATAR_1  position0.0 0.0 -0.10000001

print "jt6.pl starting step 4\n";
$sock->print("36\nCVU TinMan.wrl\n");
my @tinman1 = getlines(4);
print "jt6.pl tinman is @tinman1\n";

$sock->print("38\nSE $proto1[3] objectNodes\n$tinman1[3]\n");

$sock->print("39\nSE $proto1[3] position\n0.0 0.0 10.0\n");

system ("sleep 10");
print "changing viewpoint\n";
$sock->print("40\nSE $view[3] set_bind\nFALSE\n");
$sock->print("41\nSE $view[3] position\n0.0 3.0 16.0\n");
$sock->print("42\nSE $view[3] set_bind\nTRUE\n");
system ("sleep 1");
print "changing viewpoint\n";
$sock->print("40\nSE $view[3] set_bind\nFALSE\n");
$sock->print("41\nSE $view[3] position\n0.0 2.0 16.0\n");
$sock->print("42\nSE $view[3] set_bind\nTRUE\n");
system ("sleep 1");
print "changing viewpoint\n";
$sock->print("40\nSE $view[3] set_bind\nFALSE\n");
$sock->print("41\nSE $view[3] position\n0.0 1.0 16.0\n");
$sock->print("42\nSE $view[3] set_bind\nTRUE\n");
system ("sleep 1");
print "changing viewpoint\n";
$sock->print("40\nSE $view[3] set_bind\nFALSE\n");
$sock->print("41\nSE $view[3] position\n0.0 0.0 16.0\n");
$sock->print("42\nSE $view[3] set_bind\nTRUE\n");
system ("sleep 1");
print "changing viewpoint\n";
$sock->print("40\nSE $view[3] set_bind\nFALSE\n");
$sock->print("41\nSE $view[3] position\n0.0 -1.0 16.0\n");
$sock->print("42\nSE $view[3] set_bind\nTRUE\n");
system ("sleep 10");
