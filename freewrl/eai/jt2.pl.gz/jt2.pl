# Very simple: just get the TouchSensor event and give
# a random color to the other box.

$PORT=90000;

use IO::Socket;

$server = IO::Socket::INET->new(Proto => 'tcp',
	LocalPort => $PORT,
	Listen => SOMAXCONN,
	Reuse => 1) or die("Can't set up server");

system("perl ./freewrl eai/EAISimple.wrl -best -eai localhost:$PORT &");


$sock = $server->accept();
$sock->autoflush(1);

sub getlines {
	print "jt2.pl getlines starting\n";
	my @arr;
	for(1..$_[0]) {
		# print "jt2.pl EXPECTING ROW $_\n";
		my $str = <$sock>;
		chomp $str;
		# print "jt2.pl GOT '$str'\n";
		push @arr, $str;
	}
        print "jt2.pl returning from getlines @arr\n";
	return @arr;
}

# Test the sample EAI protocol.

$a = <$sock>;
$sock->print("TJL EAI CLIENT 0.02\n");


#---------------

# get the node name of the VNET node.

$sock->print("1\nGN VNET\n");
my @l = getlines(4);
print "\njt2.pl ok, REAL node of VNET is $l[3]\n\n";


system ("sleep 2");

#---------------

#$sock->print("1\nGNAM\n");
#.my @l = getlines(4);
#print "\njt2.pl ok, Name of browser is :$l[0] :$l[1] :$l[2] :$l[3]:\n\n";

#system ("sleep 2");
#---------------

#$sock->print("1\nGCFR\n");
#my @l = getlines(4);
#print "\njt2.pl ok, Frame Rate of browser is :$l[0] :$l[1] :$l[2] :$l[3]:\n\n";

#system ("sleep 2");
#---------------

# try to see what value the headlight has...
print "jt2.pl SENDING 2 GV $l[3] isConnected\n";
$sock->print("2\nGV $l[3] isConnected\n");
my @l2 = getlines(4);
print "jt2.pl - VNET isConnected returned @l2\n\n\n\n\n\n\n";
system ("sleep 2");

#---------------
# try to see what value the port has...
print "jt2.pl SENDING 2 GV $l[3] port\n";
$sock->print("2\nGV $l[3] port\n");
my @l2 = getlines(4);
print "jt2.pl - VNET port returned @l2\n\n\n\n\n\n\n";
system ("sleep 2");

#---------------

# try to see what value the avatarNames has...
print "jt2.pl SENDING 2 GV $l[3] avatarNames\n";
$sock->print("2\nGV $l[3] avatarNames\n");
my @l2 = getlines(4);
print "jt2.pl - VNET avatarNames returned @l2\n\n\n\n\n\n\n";
system ("sleep 2");

#---------------

# try to turn the headlight on.

print "jt2.pl SENDING 2 SE $l[3] isConnected\n";
$sock->print("2\nSE $l[3] isConnected\nTRUE\n");
#my @l2 = getlines(3);
#print "jt2.pl - VNET isConnected returned @l2\n";
system ("sleep 2");
# try to see what value the headlight has...
print "jt2.pl SENDING 2 GV $l[3] isConnected\n";
$sock->print("2\nGV $l[3] isConnected\n");
my @l2 = getlines(4);
print "jt2.pl - VNET isConnected returned @l2\n\n\n\n\n\n\n";
system ("sleep 2");


#---------------

# try to set a different "viewpoint"

$sock->print("1\nGN VIEWPOINT\n");
my @r = getlines(4);
print "\njt2.pl ok, REAL node of VIEWPOINT is $r[3]\n\n";
print "jt2.pl SENDING 2 SE $r[3] position\n";
$sock->print("2\nSE $r[3] position\n0.0 0.75 10.0 \n");
system ("sleep 2");

print "jt2.pl SENDING 2 SE $r[3] position\n";
$sock->print("2\nSE $r[3] position\n0.0 0.75 20.0 \n");
system ("sleep 2");

print "jt2.pl SENDING 2 SE $r[3] position\n";
$sock->print("2\nSE $r[3] position\n0.0 0.75 30.0 \n");
system ("sleep 2");

print "jt2.pl SENDING 2 SE $r[3] position\n";
$sock->print("2\nSE $r[3] position\n0.0 0.75 10.0 \n");
system ("sleep 2");



#---------------

# try to turn the headlight off.

print "jt2.pl SENDING 2 SE $l[3] isConnected\n";
$sock->print("2\nSE $l[3] isConnected\nFALSE\n");

#---------------

