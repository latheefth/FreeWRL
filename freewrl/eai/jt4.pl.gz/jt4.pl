
# Very simple: just get the TouchSensor event and give
# a random color to the other box.

$PORT=90000;

use IO::Socket;

$server = IO::Socket::INET->new(Proto => 'tcp',
	LocalPort => $PORT,
	Listen => SOMAXCONN,
	Reuse => 1) or die("Can't set up server");

system("perl ./freewrl eai/root.wrl -best -eai localhost:$PORT eai &");


$sock = $server->accept();
$sock->autoflush(1);

# print "jt2.pl EAI CLIENT STARITNG!!!!!\n";

sub getlines {
	print "jt2.pl getlines starting\n";
	my @arr;
	for(1..$_[0]) {
		print "jt2.pl EXPECTING ROW $_\n";
		my $str = <$sock>;
		chomp $str;
		print "jt2.pl GOT '$str'\n";
		push @arr, $str;
	}
        print "jt2.pl returning from getlines @arr\n";
	return @arr;
}

# Test the sample EAI protocol.

$a = <$sock>;
$sock->print("TJL EAI CLIENT 0.02\n");


#---------------

# get the node name of the VNET node.

$sock->print("1\nGN ROOT\n");
my @l = getlines(4);
print "\njt2.pl ok, REAL node of ROOT is $l[3]\n\n";


system ("sleep 2");

#$sock->print("2\nCVS Shape { appearance Appearance { material Material { diffuseColor 0.2 0.2 0.8 } } geometry Sphere {} }\nEOT\n");
$sock->print("2\nCVS Transform { translation -1 0 0 children [ Shape { appearance Appearance { material DEF MAT Material { diffuseColor 0 0 0.8 } } geometry Cone { } } ] }\nEOT\n");


my @l2 = getlines(4);
print "jt2.pl - CVS returned @l2\n\n\n\n\n\n\n";
system ("sleep 5");

#---------------
my $count = 0;
  while ($count < 100) {
  $sock->print("3\nSE $l[3] addChildren\n$l2[3]\n");
  system ("sleep 2");
  $sock->print("3\nSE $l[3] removeChildren\n$l2[3]\n");
  system ("sleep 2");
  $count = $count+1;
}

